import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-your-tickets',
  templateUrl: './your-tickets.component.html',
  styleUrls: ['./your-tickets.component.css']
})
export class YourTicketsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
